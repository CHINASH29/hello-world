from django.shortcuts import render
from .models import logininfo


def homepage(request):
    return render(request, 'login.html')


# def login(request):
#     fname = request.GET['fullname']
#     emailid = request.GET['loginid']

#     return render(request, 'login_success.html', {'fname': fname, 'mail': emailid})


def login_info_admin(request):
    fullname = request.POST['fullname']
    loginid = request.POST['loginid']

    faculty_info = logininfo(fullname=fullname, loginid=loginid)
    faculty_info.save()

    return render(request, 'login_success.html', {'fname': fullname, 'mail': loginid})
