from django.contrib import admin
from .models import logininfo

admin.site.register(logininfo)
